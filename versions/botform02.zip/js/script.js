$(document).ready(function(){
	$(window).on('load', function(){
		/*$(".footer-blur").css({"height":$(".footer").height()})
		*//*TweenMax.to(window, 1, {delay:0.5, scrollTo:{y:0}});*/ 
	});
	/*$(window).on('scroll', function() {
        var y_scroll_pos = window.pageYOffset;
        var scroll_pos_test = $(".msg").height();
        if(y_scroll_pos > scroll_pos_test) {
            $('.title').css({"position":"fixed","width":"100%",top:""});
        } 
    });*/
	
	/*
	TweenMax.set(".msg", {css: { opacity:0 }}); 

	function tlComplete(){
		tl.restart();
	};

	var tl = new TimelineMax({
		onComplete:tlComplete
	});

	tl.insert( TweenMax.staggerTo(".msg", 0.5, {	
		delay:2,
		top:-10,
		opacity:1,
		ease:Back.easeOut
    }, 2) );*/    
});