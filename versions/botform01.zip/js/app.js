var app = angular.module('botform',[]);

app.controller('botCtrl', function($scope, $timeout, $window, $http){        
    $scope.data = {
        "stages":"12",
        "samples":[{            
                "q":"Hello there, how are you doing?",
                "a":"I'm doing just fine."
            },{            
                "q":"Check out this bubble!",
                "a":"It's pretty cool!"
            },{            
                "q":"How may I help you today?",
                "a":"Give me yesterday's messages."
            },{            
                "q":"What's up, new user?",
                "a":"Nothing much, you say?"
            },{            
                "q":"I'm a cat-bot. Hello hooman!",
                "a":"Hello Catty"
            },{            
                "q":"This question has no answer.",
                "a":""
        }],
        "questions":[
            "Hello there, how are you doing?",
            "How may I help you today?",
            "Top o' the evening to you, good sire!",
            "I'm a cat-bot. Hello hooman!",
            "What's up, new user?",
            "Check out this bubble!",
            "Why did you break my heart?",
            "To be or not to be?",
            "Do you wish to call someone?"
        ],
        "answers":{
            "positive":[
                "Fine",
                "Cool",     
                "Sure",
                "Yes",      
                "Yes Please",
                "Thanks, bot!"
            ],
            "negative":[
                "Duh-uh!",                              
                "No",
                "No, Thanks!",
                "Nuh-uh!",              
                "negative",
                "area 51"
            ]
        },          
        "options":[
            "It's pretty cool!",
            "I'm doing just fine.",
            "Yesterday's messages.",
            "Well yes, it is a Rolex.",
            "Did'nt mean to.",
            "Stupid question, bot."                 
        ]        
    };   
    
    $scope.generate = function(no){
        return Math.floor((Math.random() * no));
    };

    $scope.questions = []; 
    $scope.options = []; 
    $scope.ques_no = $scope.generate(9);
    $scope.$watch(function() {
        return "options";
    }, function() {
            $scope.shiftUp(); 
        // Wait for templates to render
        $scope.$evalAsync(function() {
            // Finally, directives are evaluated
            // and templates are renderer here
        });
    });

    $scope.shiftUp = function(){
        console.log("scroll");        
    };

    $scope.undoReply = function(){
        if($scope.questions.length > 0 && $scope.questions[0].a != ""){
            $scope.questions.pop();
            var length = $scope.questions.length - 1;
            $scope.questions[length].a = ""; 
        }
        else
            console.log("No can cancel");
        console.log("Undone");        
    };

    $scope.sendForm = function(){
        $http({
            url: "https://formkeep.com/f/339fb2dceb6e",
            method: "POST",
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            data: $scope.questions
          }).success(function(data, status, headers, config) {
              console.log(data);
          }).error(function(data, status, headers, config) {
            this.status = status;
        });          
    };

    $scope.addQuestion = function(){
        /*
            Randomize question here
        */
        var qno = $scope.generate(9);
        $scope.questions.push({
            "q" : $scope.data.questions[qno],
            "a" : ""
        });          
        $scope.ques_no = qno;     
        $scope.addOptions();
    };

    $scope.addAnswer = function(e){
        /*
            Add answer here
        */
        var h = $(".msg-contain").height();
        var length = $scope.questions.length - 1;
        $scope.questions[length].a = e;     
        TweenMax.to($window, 0.2, {scrollTo:{y:"+="+h}});
        $timeout( $scope.addQuestion, 1000);                                   
    };

    $scope.startBot = function(){
        $scope.addQuestion();
    };

    $scope.addOptions = function(){
        /*
            Randomize options here
        */
        var qno;
        var h = $(".msg-contain").height();
        $scope.options = [];
        qno = $scope.generate(6);
        $scope.options.push($scope.data.answers.positive[qno]);
        qno = $scope.generate(6);
        $scope.options.push($scope.data.answers.negative[qno]);
        TweenMax.to($window, 0.2, {scrollTo:{y:"+="+h}});
    };
});
